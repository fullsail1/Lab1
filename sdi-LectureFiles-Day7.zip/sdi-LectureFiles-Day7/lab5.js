

//how you start an object?
/*
"myWhip" :
 
	
	[ 
		{
		"make" : "range rover",
		"model": "sport ltd boss edi",
		"color": "domino",
		"wheels": "dubz",
		"top speed: 0;
		"current speed", 0;
		},
	]	
			var myAcceleration = function (){
			i = 5.[0];
			
			console.log(myAcceleration);
		*/
/*		
var indexer = functio(mystring){
	
	console.log = mystringin zz
	
	
}*/


		 
	
	
	
var myStatement = "no dogs allowed";


