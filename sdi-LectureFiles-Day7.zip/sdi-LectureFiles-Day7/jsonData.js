
var jsonData = {
	
	"cars":
	[
		{
			"make": "Ford",
			"model": "maverick",
			"year":  1976,
		},
	
		{
			"make": "buick",
			"model": "regatta",
			"year":  1991,
			
			
		}
	 	
	]
};

//alert("JavaScript works!");
/*

var cubeArea;
//objects

var myCube = {

length: 15, 
width:	15, 
height: 15,
cubeName:  "matrix",
units:     "iunits",
getArea: 	function() {

	var area = this.length * this.width * this.height;
	return area;

	}
};

//main code
console.log("the cube length is " + myCube.length);
myCube.length = 20;
console.log("the new length is" + myCube.length);

cubeArea = myCube.getArea();
console.log("The area of the cube is " + cubeArea + "inches");
*/
/*
var meAntdog = {
	
	lastname: "Hicks",
	firstname: "Anthony",
	age:  32,
	setAge: function() {
		this.age= this.age+1;
		
		
	}
	
};
	console.log();
	meAntdog.setAge();
	console.log();
	


console.log(jsonData.cars[0].model);




var boss = {
	firstname: "Pontius",
	lastname: "Creatus",
	age: 33,
	height: "68 inches",
	setAge: function(){
		this.age = this.age+1;
	}


};
	console.log(" the boss hurt that guy for calling him " + boss.firstname  + " smiling ");
	boss.setAge(43);
	console.log( " the boss just turned " + boss.age + " yesterday ");
	
*/
