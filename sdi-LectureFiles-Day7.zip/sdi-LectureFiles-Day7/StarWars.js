var jsonData = {
	
	"goodGuys":
	[
		{
			"firstName": "Luke",
			"lastName": "SkyWalker",
			"alliance": "Rebel",
			"age": 19
		},
		{
			"firstName": "Leia",
			"lastName": "Organa",
			"alliance": "Rebel",
			"age": 19
		},
		{
			"firstName": "Han",
			"lastName": "Solo",
			"alliance": "Independent",
			"age": 39
		}
	],
	"badGuys":
	[
		{
			"firstName": "Darth",
			"lastName": "Vader",
			"alliance": "Empire",
			"age": 38
		},
		{
			"firstName": "Grand Moff",
			"lastName": "Tarkin",
			"alliance": "Empire",
			"age": 70
		},
		{
			"firstName": "Emperor",
			"lastName": "Palpatine",
			"alliance": "Empire",
			"age": 75
		}
	]
	
};
