// Anthony Hicks
//SDI lab 7

var drinksJson = {
	
	"drafts": 
	[
		{
			"beer" : "miller",
			"size" : "Tall boy",
			"country" : "USA",
			"type" : "light"
		},
		{
			"beer" : "sam adams",
			"size" : "Small glass",
			"country" : "USA",
			"type" : "lager"	
		}

]
	
	
	
};



