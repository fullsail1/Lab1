alert("JavaScript works! bossplaya on deck sdi 1409 day 2 lecture DC DMV WE get it poppin");

var myHomeAddress = "187 Hollow point driveby";
var Favorite Clu = "Versace store ";
var NumberOfMiles = 7.18;
var typeOfCarToDrive = "benz";

//my confirms
myHomeAddress = prompt("reconfirm your address:", " 187 Hollow point driveby");
typeOfCarToDrive = confirm(" do you want to drive your benz?");




//my outputs
console.log("I run this city but where i really chill, really get it in at is" + myHomeAddress+ ".");
console.log("I cop all the hot newnew at the " + myFavoriteStore + ".");
console.log(" Your milage is " + NumberOfMiles + "to your destination" + ".");
console.log(" Why you bring your " + typeOfCarToDrive + " out to stunt on the parking lot" + ".");

