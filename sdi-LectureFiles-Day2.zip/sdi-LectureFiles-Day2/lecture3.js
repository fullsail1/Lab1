//alert("JavaScript works! bossplaya on deck sdi 1409 day 2 lecture DC DMV WE get it poppin");

var myHomeAddress = "123 Fire Lane";
var myFavoriteStore = " Versace store ";
var NumberOfMiles = 7.18;
var Goodweather = false;



//my outputs
console.log("I invite my friends to " + myHomeAddress+ " on football sundays.");
console.log(" My boss buys suits from " + myFavoriteStore + ".");
console.log(" Your milage is " + NumberOfMiles + "to your destination" + ".");
console.log(" Is it good grillin' weather " + Goodweather + "?");

//my confirms
myHomeAddress = prompt("reconfirm your address:", " 123 Fire Lane ");
Goodweather = confirm(" Did the weather get better? " );

// output 2

console.log(" We'll still meet at " + myHomeAddress + ".");
console.log( Goodweather + " The weather got better" + " So bring some charcoal!");


